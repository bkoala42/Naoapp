//
//  ControlViewController.swift
//  LAN Scan
//
//  Created by giovanniiodice on 28/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//
import UIKit
import Foundation
import QuartzCore
import CoreMotion
import SwiftSocket


class ControlViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var sayTextField: UITextField!
    
    // bottoni movimento *************
    @IBOutlet weak var gira_sx: UIButton!
    @IBOutlet weak var gira_dx: UIButton!
    @IBOutlet weak var vai_avanti: UIButton!
    @IBOutlet weak var vai_sx: UIButton!
    @IBOutlet weak var vai_dx: UIButton!
    @IBOutlet weak var vai_indietro: UIButton!
    
    
    @IBAction func gira_sx_premuto(_ sender: UIButton) {
        self.holdDown(sender: sender)
    }
    @IBAction func gira_dx_premuto(_ sender: UIButton) {
        self.holdDown(sender: sender)
    }
    @IBAction func vai_avanti_premuto(_ sender: UIButton) {
        self.holdDown(sender: sender)
    }
    @IBAction func vai_sx_premuto(_ sender: UIButton) {
        self.holdDown(sender: sender)
    }
    @IBAction func vai_dx_premuto(_ sender: UIButton) {
        self.holdDown(sender: sender)
    }
    @IBAction func vai_indietro_premuto(_ sender: UIButton) {
        self.holdDown(sender: sender)
    }
    //*************************
    
    
    
    
    
    
    var client : TCPClient?
    
    var thresholdDS = 30
    var thresholdAI = 20
    var buttonIsStart = false
    let motionManager = CMMotionManager()
    var condition : Bool?
    var stringToSay : String = ""
    
    func degrees(_ radians:Double) -> Double {
        return 180 / Double.pi * radians
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set connessione
        client = TCPClient(address: ipAddress, port: 7783)
        
        // Do any additional setup after loading the view.
        self.sayTextField.delegate = self
        hideKeyboardWhenTappedAroundPers()
        
        // settings buttons
        // gira_dx
        gira_dx.backgroundColor = .clear
        gira_dx.layer.cornerRadius = 5
        gira_dx.layer.borderWidth = 1
        gira_dx.layer.borderColor = UIColor.lightGray.cgColor
        // gira_sx
        gira_sx.backgroundColor = .clear
        gira_sx.layer.cornerRadius = 5
        gira_sx.layer.borderWidth = 1
        gira_sx.layer.borderColor = UIColor.lightGray.cgColor
        // vai_avanti
        vai_avanti.backgroundColor = .clear
        vai_avanti.layer.cornerRadius = 5
        vai_avanti.layer.borderWidth = 1
        vai_avanti.layer.borderColor = UIColor.lightGray.cgColor
        // vai_sx
        vai_sx.backgroundColor = .clear
        vai_sx.layer.cornerRadius = 5
        vai_sx.layer.borderWidth = 1
        vai_sx.layer.borderColor = UIColor.lightGray.cgColor
        // vai_dx
        vai_dx.backgroundColor = .clear
        vai_dx.layer.cornerRadius = 5
        vai_dx.layer.borderWidth = 1
        vai_dx.layer.borderColor = UIColor.lightGray.cgColor
        // vai_indietro
        vai_indietro.backgroundColor = .clear
        vai_indietro.layer.cornerRadius = 5
        vai_indietro.layer.borderWidth = 1
        vai_indietro.layer.borderColor = UIColor.lightGray.cgColor
        // *****************
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if ipAddress != ""{
            self.client = TCPClient(address: ipAddress, port: 7783)
        }
    }
    
    
    
    // CODICE PER SOCKET
    // METODI PER MANDARE E RICEVERE DATI TRAMITE SOCKET
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        return String(bytes: response, encoding: .utf8)
    }
    
    
    private func sendRequest(string: String, using client: TCPClient) -> String? {
        switch client.send(string: string) {
        case .success:
            var resp = readResponse(from: client)
            while resp == nil{
                resp = readResponse(from: client)
            }
            return resp
        case .failure(let error):
            print(String(describing: error))
            return nil
        }
    }
    
    private func setCommand(_string : String){
        guard let client = client else { return }
        
        switch client.connect(timeout: 10) {
        case .success:
            //SEND RICHIESTA
            if let response = sendRequest(string: _string, using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
        }
        client.close()
    }
    
}

// METODI DEI BOTTONI
extension ControlViewController {
    @IBAction func standButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNStand")
    }
    @IBAction func standInitButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNStandInit")
    }
    @IBAction func standZeroButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNStandZero")
    }
    @IBAction func sitButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNSit")
    }
    @IBAction func relaxButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNSitRelax")
    }
    @IBAction func bellyButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNLyingBelly")
    }
    @IBAction func backButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNLyingBack")
    }
    @IBAction func crouchButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNCrouch")
    }
    
    @IBAction func turnLeftButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEturnLeft")
        self.holdRelease(sender: sender)
    }
    @IBAction func turnRightButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEturnRight")
        self.holdRelease(sender: sender)
    }
    @IBAction func moveRightButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEright")
        self.holdRelease(sender: sender)
    }
    @IBAction func moveLeftButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEleft")
        self.holdRelease(sender: sender)
    }
    @IBAction func moveForwardButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEforward")
        self.holdRelease(sender: sender)
    }
    @IBAction func moveBackwardButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEbackward")
        self.holdRelease(sender: sender)
    }
    
    
    //target functions
    func holdDown(sender:UIButton)
    {
        sender.backgroundColor = UIColor.lightGray
    }
    
    func holdRelease(sender:UIButton)
    {
        sender.backgroundColor = UIColor.white
    }
    
    
    //TextField Delegate
     func textFieldDidBeginEditing(_ textField: UITextField) {
        self.stringToSay = textField.text!
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.stringToSay = textField.text!
    }
    
    
    func hideKeyboardWhenTappedAroundPers() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ControlViewController.dismissKeyboardd))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboardd() {
        view.endEditing(true)
        self.sayTextField.text = ""
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        dismissKeyboardd()
        setCommand(_string: "DOITsay" + self.stringToSay)
        return true
    }
    
}
