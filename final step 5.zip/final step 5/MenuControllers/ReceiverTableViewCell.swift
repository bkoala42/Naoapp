//
//  ReceiverTableViewCell.swift
//  LAN Scan
//
//  Created by giovanniiodice on 28/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit

class ReceiverTableViewCell: UITableViewCell {
    @IBOutlet weak var texttLabel: UILabel?
    @IBOutlet weak var textView: UITextView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
