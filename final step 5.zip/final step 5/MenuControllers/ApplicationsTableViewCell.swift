//
//  ApplicationsTableViewCell.swift
//  LAN Scan
//
//  Created by giovanniiodice on 02/10/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit

class ApplicationsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var appLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
