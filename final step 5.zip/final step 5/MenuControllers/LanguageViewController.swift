//
//  LanguageViewController.swift
//  LAN Scan
//
//  Created by Ilaria Gigi on 23/01/18.
//  Copyright © 2018 Smart Touch. All rights reserved.
//

import UIKit

class LanguageViewController: ViewController {
    
    var selectedLanguage = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.hidesBackButton = true
    }    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func selectItalian(_ sender: Any) {
        self.selectedLanguage = "it-IT"
        
    }
    @IBAction func selectEnglish(_ sender: Any) {
        self.selectedLanguage = "en-EN"
    }
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (identifier ==  "english") {
            self.selectedLanguage = "en-EN"
            return true
        }
        if (identifier ==  "italian") {
            self.selectedLanguage = "it-IT"
            return true
        }
        return true
    }
}
