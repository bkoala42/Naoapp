//
//  InfoViewController.swift
//  LAN Scan
//
//  Created by giovanniiodice on 28/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit
import SwiftSocket


class InfoTableViewController: UITableViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate{
    
    @IBOutlet weak var volumeSlider: UISlider!
    @IBOutlet weak var volumeLabel: UILabel!
    @IBOutlet weak var ipLabel: UILabel!
    @IBOutlet weak var batteryLabel: UILabel!
    @IBOutlet weak var langTextField: UITextField!
    @IBOutlet var infoTableView: UITableView!
    //ATTENZIONE DEVI DICHIARARE PUBLIC + @OBJC + NON OPTIONAL
    //@objc public var textstr: String!
    var client: TCPClient?
    var langAvailable : [String]!
    var picker : UIPickerView!
    var langCurrent : String!
    var volCurrent : String!
    var batCurrent : String!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set refresh pagina
        /*let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: Selector(("refresh")), for: UIControlEvents.valueChanged)
         self.refreshControl = refreshControl
        */
        // set label indirizzo ip
        ipLabel.text = ipAddress
            
        // set connessione
        client = TCPClient(address: ipAddress, port: 7783)
        
            
        // set label lingua
        langCurrent = getLanguage()
            while (langCurrent == ""){
            //|| langCurrent != "English"){
            langCurrent = getLanguage()
        }
        langTextField.text = langCurrent
        
        // set label volume
        volCurrent = getVolume()
        while (volCurrent == ""){
            volCurrent = getVolume()
        }
        volumeLabel.text = volCurrent
        volumeSlider.setValue(Float(volCurrent)!, animated: true)
        
        // set label battery
        batCurrent = getBattery()
        while (batCurrent == ""){
            batCurrent = getBattery()
        }
        batteryLabel.text = batCurrent
        // Do any additional setup after loading the view.
        //hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ipLabel.text = ipAddress
        // set connessione
        client = TCPClient(address: ipAddress, port: 7783)
        
        
        // set label lingua
        langCurrent = getLanguage()
        while (langCurrent == ""){
            //|| langCurrent != "English"){
            langCurrent = getLanguage()
        }
        langTextField.text = langCurrent
        
        // set label volume
        volCurrent = getVolume()
        while (volCurrent == ""){
            volCurrent = getVolume()
        }
        volumeLabel.text = volCurrent
        volumeSlider.setValue(Float(volCurrent)!, animated: true)
        
        // set label battery
        batCurrent = getBattery()
        while (batCurrent == ""){
            batCurrent = getBattery()
        }
        batteryLabel.text = batCurrent + "%"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
     // METODI PER MANDARE E RICEVERE DATI TRAMITE SOCKET
    
    private func readResponse(from client: TCPClient) -> String? {
            guard let response = client.read(1024*10) else { return nil }
            return String(bytes: response, encoding: .utf8)
    }
    

    private func sendRequest(string: String, using client: TCPClient) -> String? {
        switch client.send(string: string) {
        case .success:
            //sleep(10)
            var resp = readResponse(from: client)
            while resp == nil{
                resp = readResponse(from: client)
            }
            return resp
        case .failure(let error):
            print(String(describing: error))
            return nil
        }
    }
    
    // METODI PER LA LINGUA
    
     func setLanguage(_string: String){
            guard let client = client else { return }
            
            switch client.connect(timeout: 10) {
            case .success:
                //SEND RICHIESTA
                if let response = sendRequest(string: "DOITlan" + _string, using: client){
                    //gestione dato in ricezione
                    print("ho ricevuto: " + response)
                }else{
                    print("errore")
                }
                
            case .failure(let error):
                print("errore di connessione al server: " + String(describing: error))
                performSegue(withIdentifier: "whoops1", sender: nil)
            }
            client.close()
        
        
    }
 func getLanguage() -> String{
    guard let client = self.client else{ return "" }
        
        switch client.connect(timeout: 10) {
        case .success:
            if let response = sendRequest(string: "RTRNlanguage", using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
                let correctRes = response.dropFirst(3)
                print(correctRes)
                self.langAvailable = correctRes.components(separatedBy: " ")
                print(langAvailable)
                //_ = langAvailable.removeLast()
                //print(langAvailable)
                if langAvailable == [""]{
                    return ""
                }
                else { return langAvailable.removeLast() }
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
            performSegue(withIdentifier: "whoops1", sender: nil)
        }
        client.close()
    return ""
    }
    
    // METODI PER IL VOLUME
    func setVolume(_string: String){
        guard let client = client else { return }
        
        switch client.connect(timeout: 10) {
        case .success:
            //SEND RICHIESTA
            if let response = sendRequest(string: "DOITvol" + _string, using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
            }else{
                print("errore")
            }
            
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
            performSegue(withIdentifier: "whoops1", sender: nil)
        }
        client.close()
    }
    
    func getVolume() -> String{
        guard let client = self.client else{ return "" }
        
        switch client.connect(timeout: 10) {
        case .success:
            if let response = sendRequest(string: "RTRNvolume", using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
                let correctRes = response.dropFirst(3)
                print(correctRes)
                return String(correctRes)
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
            performSegue(withIdentifier: "whoops1", sender: nil)
        }
        client.close()
        return ""
    }
    
    // METODO PER LA BATTERI
    func getBattery() -> String{
        guard let client = self.client else{ return "" }
        
        switch client.connect(timeout: 10) {
        case .success:
            if let response = sendRequest(string: "RTRNbattery", using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
                let correctRes = response.dropFirst(3)
                print(correctRes)
                return String(Int(Float(correctRes)!))
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
            performSegue(withIdentifier: "whoops1", sender: nil)
        }
        client.close()
        return ""
    }
    
    @IBAction func volumeChanging(_ sender: UISlider) {
        self.volCurrent = String(Int(self.volumeSlider.value))
        setVolume(_string: self.volCurrent)
        volumeLabel.text = self.volCurrent
    }
    
    
    // METODI PER GESTIRE LA TABLE VIEW CON CELLE FISSE
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0{
            return 1
        }
        else if section == 1 {
            return 1
        }
        else if section == 2 {
            return 1
        }
        else if section == 3 {
            return 1
        }
        return 1
    }
    
    
    // CODICE PER IL PICKER VIEW
    
    func pickUp(_ textField : UITextField){
        
        // UIPickerView
        self.picker = UIPickerView(frame:CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 216))
        self.picker.delegate = self
        self.picker.dataSource = self
        //self.picker.backgroundColor = UIColor.white
        let index : Int = self.langAvailable.index(of: langTextField.text!) as Int!
        self.picker.selectRow(index, inComponent: 0, animated: true)
        textField.inputView = self.picker
        
        // ToolBar
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
        toolBar.sizeToFit()
        
        // Adding Button ToolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(InfoTableViewController.doneClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(InfoTableViewController.cancelClick))
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        textField.inputAccessoryView = toolBar
        
    }
 
    //MARK:- PickerView Delegate & DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.langAvailable.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.langAvailable[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.langTextField.text = langAvailable[row]
    }
    
    //MARK:- TextFiled Delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.pickUp(langTextField)
    }
    
    //MARK:- Button
    @objc func doneClick() {
        //hideKeyboardWhenTappedAround()
        langTextField.resignFirstResponder()
        setLanguage(_string: langTextField.text!)
    }
    @objc func cancelClick() {
        //hideKeyboardWhenTappedAround()
        langTextField.resignFirstResponder()
    }
   
    
}
