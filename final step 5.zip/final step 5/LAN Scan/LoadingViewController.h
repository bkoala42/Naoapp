//
//  LoadingViewController.h
//  LAN Scan
//
//  Created by giovanniiodice on 25/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SwiftViewController;
@class InfoTableViewController;
@interface LoadingViewController : UIViewController
@property (nonatomic, strong) IBOutlet UITextField* textField;
@property (nonatomic,strong) IBOutlet UIButton* search;
@property (nonatomic,strong) IBOutlet UIButton* doneButton;
@end
